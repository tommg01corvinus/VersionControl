﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VAR_2021.Entities
{
    class PortfolioItem
    {
        public string Index { get; set; }
        public decimal Volume { get; set; }
    }
}
